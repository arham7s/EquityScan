import { CompanyMetrics, ScoredCompany, ClusterType, LBOMetrics } from '../types';

/**
 * Calculates a simplified LBO return profile
 */
export function calculateLBO(c: CompanyMetrics, entryMultiple: number = 10, targetDebt: number = 4.5, exitMultiple: number = 12, years: number = 5): LBOMetrics {
  const entryEV = c.ebitda * entryMultiple;
  const entryDebt = c.ebitda * targetDebt;
  const entryEquity = entryEV - entryDebt;

  // Assume 5% annual EBITDA growth and 20% FCF conversion for debt paydown
  const exitEbitda = c.ebitda * Math.pow(1 + (c.revenueGrowth / 100), years);
  const exitEV = exitEbitda * exitMultiple;
  
  // Simplified debt paydown: 30% of cumulative EBITDA over 5 years
  const g = c.revenueGrowth / 100;
  const totalEbitda = g === 0 ? c.ebitda * years : c.ebitda * ((Math.pow(1 + g, years) - 1) / g);
  const debtPaydown = totalEbitda * 0.3;
  const exitDebt = Math.max(0, entryDebt - debtPaydown);
  
  const exitEquity = exitEV - exitDebt;
  const moic = exitEquity / entryEquity;
  const projectedIRR = (Math.pow(moic, 1 / years) - 1) * 100;

  return {
    projectedIRR: Math.round(projectedIRR * 10) / 10,
    moic: Math.round(moic * 10) / 10,
    entryEquity: Math.round(entryEquity),
    exitValue: Math.round(exitEquity),
    debtPaydown: Math.round(debtPaydown)
  };
}

/**
 * Simple K-Means implementation for clustering companies
 */
export function clusterCompanies(companies: CompanyMetrics[]): ScoredCompany[] {
  const scored = companies.map(c => {
    // Normalize metrics (0-1)
    const nEbitda = Math.min(Math.max(c.ebitdaMargin / 40, 0), 1);
    const nDebt = Math.max(1 - (c.debtToEbitda / 10), 0);
    const nGrowth = Math.min(Math.max(c.revenueGrowth / 30, 0), 1);
    const nRoic = Math.min(Math.max(c.roic / 50, 0), 1);
    const nFcf = c.fcfStability;
    const nValuation = Math.max(1 - (c.valuationMultiple / 25), 0);
    const nSentiment = (c.sentimentScore + 1) / 2;

    // Weights (PE specific)
    const score = (
      nEbitda * 0.10 +
      nGrowth * 0.10 +
      nRoic * 0.15 +
      nFcf * 0.25 +
      nValuation * 0.25 +
      nDebt * 0.10 +
      nSentiment * 0.05
    ) * 100;

    let cluster: ClusterType = 'Stable Cash Cow';
    if (c.ebitdaMargin < 5 && c.debtToEbitda > 6) {
      cluster = 'Distressed Target';
    } else if (c.revenueGrowth > 15 && c.roic > 20) {
      cluster = 'Growth Buyout';
    } else if (c.ebitdaMargin < 10 && c.roic > 15 && c.revenueGrowth > 0) {
      cluster = 'Turnaround Case';
    } else if (c.valuationMultiple > 18) {
      cluster = 'Overvalued';
    }

    return {
      ...c,
      peScore: Math.round(score),
      cluster,
      rank: 0,
      lbo: calculateLBO(c, c.valuationMultiple, c.debtToEbitda, c.valuationMultiple + 2)
    };
  });

  return scored
    .sort((a, b) => b.peScore - a.peScore)
    .map((c, i) => ({ ...c, rank: i + 1 }));
}

export const MOCK_COMPANIES: CompanyMetrics[] = [
  { id: '1', name: 'TechFlow Systems', industry: 'Software', ebitdaMargin: 35, debtToEbitda: 1.2, revenueGrowth: 25, roic: 42, fcfStability: 0.95, valuationMultiple: 22, revenue: 1200, ebitda: 420, marketCap: 9240, sentimentScore: 0.8, sentimentHistory: [{ date: '2025-10', score: 0.5 }, { date: '2025-11', score: 0.6 }, { date: '2025-12', score: 0.7 }, { date: '2026-01', score: 0.75 }, { date: '2026-02', score: 0.8 }] },
  { id: '2', name: 'Global Logistics Corp', industry: 'Industrial', ebitdaMargin: 12, debtToEbitda: 4.5, revenueGrowth: 4, roic: 8, fcfStability: 0.8, valuationMultiple: 8, revenue: 5500, ebitda: 660, marketCap: 5280, sentimentScore: 0.2, sentimentHistory: [{ date: '2025-10', score: 0.3 }, { date: '2025-11', score: 0.25 }, { date: '2025-12', score: 0.2 }, { date: '2026-01', score: 0.15 }, { date: '2026-02', score: 0.2 }] },
  { id: '3', name: 'RetailEdge Inc', industry: 'Retail', ebitdaMargin: 4, debtToEbitda: 8.2, revenueGrowth: -2, roic: 3, fcfStability: 0.4, valuationMultiple: 5, revenue: 8000, ebitda: 320, marketCap: 1600, sentimentScore: -0.6, sentimentHistory: [{ date: '2025-10', score: -0.2 }, { date: '2025-11', score: -0.3 }, { date: '2025-12', score: -0.4 }, { date: '2026-01', score: -0.5 }, { date: '2026-02', score: -0.6 }] },
  { id: '4', name: 'HealthCore Solutions', industry: 'Healthcare', ebitdaMargin: 22, debtToEbitda: 2.8, revenueGrowth: 12, roic: 18, fcfStability: 0.9, valuationMultiple: 14, revenue: 2400, ebitda: 528, marketCap: 7392, sentimentScore: 0.4, sentimentHistory: [{ date: '2025-10', score: 0.2 }, { date: '2025-11', score: 0.3 }, { date: '2025-12', score: 0.35 }, { date: '2026-01', score: 0.4 }, { date: '2026-02', score: 0.4 }] },
  { id: '5', name: 'Precision Mfg', industry: 'Manufacturing', ebitdaMargin: 18, debtToEbitda: 3.2, revenueGrowth: 6, roic: 22, fcfStability: 0.85, valuationMultiple: 10, revenue: 1500, ebitda: 270, marketCap: 2700, sentimentScore: 0.1, sentimentHistory: [{ date: '2025-10', score: 0.0 }, { date: '2025-11', score: 0.05 }, { date: '2025-12', score: 0.1 }, { date: '2026-01', score: 0.12 }, { date: '2026-02', score: 0.1 }] },
  { id: '6', name: 'CloudScale AI', industry: 'Software', ebitdaMargin: -5, debtToEbitda: 0.5, revenueGrowth: 85, roic: -10, fcfStability: 0.2, valuationMultiple: 45, revenue: 500, ebitda: -25, marketCap: 22500, sentimentScore: 0.9, sentimentHistory: [{ date: '2025-10', score: 0.6 }, { date: '2025-11', score: 0.75 }, { date: '2025-12', score: 0.85 }, { date: '2026-01', score: 0.9 }, { date: '2026-02', score: 0.95 }] },
  { id: '7', name: 'Legacy Brands Co', industry: 'Consumer', ebitdaMargin: 28, debtToEbitda: 5.5, revenueGrowth: 1, roic: 12, fcfStability: 0.98, valuationMultiple: 12, revenue: 3200, ebitda: 896, marketCap: 10752, sentimentScore: 0.0, sentimentHistory: [{ date: '2025-10', score: 0.1 }, { date: '2025-11', score: 0.05 }, { date: '2025-12', score: 0.0 }, { date: '2026-01', score: -0.05 }, { date: '2026-02', score: 0.0 }] },
  { id: '8', name: 'EcoPower Utilities', industry: 'Energy', ebitdaMargin: 45, debtToEbitda: 6.8, revenueGrowth: 3, roic: 6, fcfStability: 0.9, valuationMultiple: 15, revenue: 6000, ebitda: 2700, marketCap: 40500, sentimentScore: -0.2, sentimentHistory: [{ date: '2025-10', score: 0.0 }, { date: '2025-11', score: -0.1 }, { date: '2025-12', score: -0.15 }, { date: '2026-01', score: -0.2 }, { date: '2026-02', score: -0.25 }] },
  { id: '9', name: 'BioGenix Labs', industry: 'Biotech', ebitdaMargin: 15, debtToEbitda: 2.1, revenueGrowth: 40, roic: 25, fcfStability: 0.6, valuationMultiple: 28, revenue: 800, ebitda: 120, marketCap: 3360, sentimentScore: 0.7, sentimentHistory: [{ date: '2025-10', score: 0.4 }, { date: '2025-11', score: 0.5 }, { date: '2025-12', score: 0.6 }, { date: '2026-01', score: 0.65 }, { date: '2026-02', score: 0.7 }] },
  { id: '10', name: 'Urban Mobility', industry: 'Transport', ebitdaMargin: 2, debtToEbitda: 7.5, revenueGrowth: 15, roic: 5, fcfStability: 0.3, valuationMultiple: 6, revenue: 1200, ebitda: 24, marketCap: 144, sentimentScore: -0.4, sentimentHistory: [{ date: '2025-10', score: -0.1 }, { date: '2025-11', score: -0.2 }, { date: '2025-12', score: -0.3 }, { date: '2026-01', score: -0.4 }, { date: '2026-02', score: -0.45 }] },
  { id: '11', name: 'DataSecure Ltd', industry: 'Cybersecurity', ebitdaMargin: 20, debtToEbitda: 1.5, revenueGrowth: 30, roic: 35, fcfStability: 0.88, valuationMultiple: 20, revenue: 950, ebitda: 190, marketCap: 3800, sentimentScore: 0.6, sentimentHistory: [{ date: '2025-10', score: 0.3 }, { date: '2025-11', score: 0.4 }, { date: '2025-12', score: 0.5 }, { date: '2026-01', score: 0.55 }, { date: '2026-02', score: 0.6 }] },
  { id: '12', name: 'HeavyIron Works', industry: 'Construction', ebitdaMargin: 8, debtToEbitda: 5.2, revenueGrowth: 2, roic: 7, fcfStability: 0.75, valuationMultiple: 7, revenue: 4200, ebitda: 336, marketCap: 2352, sentimentScore: -0.1, sentimentHistory: [{ date: '2025-10', score: 0.1 }, { date: '2025-11', score: 0.05 }, { date: '2025-12', score: 0.0 }, { date: '2026-01', score: -0.05 }, { date: '2026-02', score: -0.1 }] },
  { id: '13', name: 'SmartHome Devices', industry: 'Consumer Electronics', ebitdaMargin: 14, debtToEbitda: 3.8, revenueGrowth: 18, roic: 15, fcfStability: 0.7, valuationMultiple: 16, revenue: 2100, ebitda: 294, marketCap: 4704, sentimentScore: 0.3, sentimentHistory: [{ date: '2025-10', score: 0.1 }, { date: '2025-11', score: 0.15 }, { date: '2025-12', score: 0.2 }, { date: '2026-01', score: 0.25 }, { date: '2026-02', score: 0.3 }] },
  { id: '14', name: 'Oceanic Shipping', industry: 'Logistics', ebitdaMargin: 30, debtToEbitda: 4.2, revenueGrowth: 5, roic: 10, fcfStability: 0.85, valuationMultiple: 9, revenue: 3800, ebitda: 1140, marketCap: 10260, sentimentScore: 0.1, sentimentHistory: [{ date: '2025-10', score: -0.1 }, { date: '2025-11', score: 0.0 }, { date: '2025-12', score: 0.05 }, { date: '2026-01', score: 0.1 }, { date: '2026-02', score: 0.12 }] },
  { id: '15', name: 'FinTech Prime', industry: 'Finance', ebitdaMargin: 40, debtToEbitda: 0.8, revenueGrowth: 22, roic: 45, fcfStability: 0.92, valuationMultiple: 24, revenue: 1800, ebitda: 720, marketCap: 17280, sentimentScore: 0.85, sentimentHistory: [{ date: '2025-10', score: 0.6 }, { date: '2025-11', score: 0.7 }, { date: '2025-12', score: 0.75 }, { date: '2026-01', score: 0.8 }, { date: '2026-02', score: 0.85 }] },
  { id: '16', name: 'Solaris Energy', industry: 'Energy', ebitdaMargin: 25, debtToEbitda: 3.5, revenueGrowth: 15, roic: 14, fcfStability: 0.8, valuationMultiple: 12, revenue: 3000, ebitda: 750, marketCap: 9000, sentimentScore: 0.5, sentimentHistory: [{ date: '2025-10', score: 0.2 }, { date: '2025-11', score: 0.3 }, { date: '2025-12', score: 0.4 }, { date: '2026-01', score: 0.45 }, { date: '2026-02', score: 0.5 }] },
  { id: '17', name: 'AutoDrive Systems', industry: 'Automotive', ebitdaMargin: 10, debtToEbitda: 2.5, revenueGrowth: 50, roic: 20, fcfStability: 0.5, valuationMultiple: 30, revenue: 1000, ebitda: 100, marketCap: 3000, sentimentScore: 0.75, sentimentHistory: [{ date: '2025-10', score: 0.4 }, { date: '2025-11', score: 0.55 }, { date: '2025-12', score: 0.65 }, { date: '2026-01', score: 0.7 }, { date: '2026-02', score: 0.75 }] },
  { id: '18', name: 'GreenHarvest Foods', industry: 'Consumer', ebitdaMargin: 15, debtToEbitda: 4.0, revenueGrowth: 8, roic: 10, fcfStability: 0.9, valuationMultiple: 11, revenue: 2500, ebitda: 375, marketCap: 4125, sentimentScore: 0.3, sentimentHistory: [{ date: '2025-10', score: 0.1 }, { date: '2025-11', score: 0.15 }, { date: '2025-12', score: 0.2 }, { date: '2026-01', score: 0.25 }, { date: '2026-02', score: 0.3 }] },
  { id: '19', name: 'NanoChip Tech', industry: 'Semiconductors', ebitdaMargin: 45, debtToEbitda: 1.0, revenueGrowth: 35, roic: 55, fcfStability: 0.96, valuationMultiple: 28, revenue: 4000, ebitda: 1800, marketCap: 50400, sentimentScore: 0.9, sentimentHistory: [{ date: '2025-10', score: 0.7 }, { date: '2025-11', score: 0.8 }, { date: '2025-12', score: 0.85 }, { date: '2026-01', score: 0.9 }, { date: '2026-02', score: 0.92 }] },
  { id: '20', name: 'SkyHigh Airlines', industry: 'Transport', ebitdaMargin: 5, debtToEbitda: 9.0, revenueGrowth: 2, roic: 4, fcfStability: 0.3, valuationMultiple: 4, revenue: 10000, ebitda: 500, marketCap: 2000, sentimentScore: -0.5, sentimentHistory: [{ date: '2025-10', score: -0.2 }, { date: '2025-11', score: -0.3 }, { date: '2025-12', score: -0.4 }, { date: '2026-01', score: -0.5 }, { date: '2026-02', score: -0.55 }] },
  { id: '21', name: 'MedTech Innovate', industry: 'Healthcare', ebitdaMargin: 18, debtToEbitda: 1.8, revenueGrowth: 22, roic: 30, fcfStability: 0.8, valuationMultiple: 18, revenue: 1200, ebitda: 216, marketCap: 3888, sentimentScore: 0.5, sentimentHistory: [{ date: '2025-10', score: 0.2 }, { date: '2025-11', score: 0.3 }, { date: '2025-12', score: 0.4 }, { date: '2026-01', score: 0.45 }, { date: '2026-02', score: 0.5 }] },
  { id: '22', name: 'CloudNet Security', industry: 'Cybersecurity', ebitdaMargin: 25, debtToEbitda: 0.5, revenueGrowth: 45, roic: 40, fcfStability: 0.9, valuationMultiple: 32, revenue: 600, ebitda: 150, marketCap: 4800, sentimentScore: 0.8, sentimentHistory: [{ date: '2025-10', score: 0.5 }, { date: '2025-11', score: 0.6 }, { date: '2025-12', score: 0.7 }, { date: '2026-01', score: 0.75 }, { date: '2026-02', score: 0.8 }] },
  { id: '23', name: 'SteelWorks Global', industry: 'Manufacturing', ebitdaMargin: 10, debtToEbitda: 5.8, revenueGrowth: 3, roic: 9, fcfStability: 0.7, valuationMultiple: 6, revenue: 4500, ebitda: 450, marketCap: 2700, sentimentScore: -0.2, sentimentHistory: [{ date: '2025-10', score: 0.0 }, { date: '2025-11', score: -0.1 }, { date: '2025-12', score: -0.15 }, { date: '2026-01', score: -0.2 }, { date: '2026-02', score: -0.22 }] },
  { id: '24', name: 'FreshGrocer', industry: 'Retail', ebitdaMargin: 3, debtToEbitda: 4.2, revenueGrowth: 5, roic: 12, fcfStability: 0.95, valuationMultiple: 10, revenue: 12000, ebitda: 360, marketCap: 3600, sentimentScore: 0.1, sentimentHistory: [{ date: '2025-10', score: 0.0 }, { date: '2025-11', score: 0.05 }, { date: '2025-12', score: 0.08 }, { date: '2026-01', score: 0.1 }, { date: '2026-02', score: 0.12 }] },
  { id: '25', name: 'Quantum Computing', industry: 'Software', ebitdaMargin: 5, debtToEbitda: 0.5, revenueGrowth: 150, roic: 10, fcfStability: 0.2, valuationMultiple: 80, revenue: 500, ebitda: 25, marketCap: 2000, sentimentScore: 0.95, sentimentHistory: [{ date: '2025-10', score: 0.7 }, { date: '2025-11', score: 0.8 }, { date: '2025-12', score: 0.9 }, { date: '2026-01', score: 0.92 }, { date: '2026-02', score: 0.95 }] },
];
