import React, { useState, useMemo, useEffect } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  AlertCircle, 
  Target, 
  Filter, 
  Search, 
  ArrowUpRight, 
  ArrowDownRight,
  ChevronDown,
  Info,
  Layers,
  Activity,
  DollarSign,
  X,
  Zap,
  ShieldCheck,
  PieChart as PieChartIcon,
  MessageSquare,
  Sparkles,
  Loader2
} from 'lucide-react';
import { 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  ZAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  LineChart,
  Line,
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { GoogleGenAI } from "@google/genai";

import { ScoredCompany, ClusterType, LBOMetrics } from './types';
import { clusterCompanies, MOCK_COMPANIES, calculateLBO } from './utils/ml';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const CLUSTER_COLORS: Record<ClusterType, string> = {
  'Growth Buyout': '#10b981', // Emerald
  'Distressed Target': '#ef4444', // Red
  'Turnaround Case': '#f59e0b', // Amber
  'Stable Cash Cow': '#3b82f6', // Blue
  'Overvalued': '#8b5cf6', // Violet
};

const INDUSTRY_MEDIANS: Record<string, number> = {
  'Software': 18.5,
  'Industrial': 9.2,
  'Retail': 7.5,
  'Healthcare': 12.8,
  'Manufacturing': 8.5,
  'Consumer': 11.0,
  'Energy': 14.2,
  'Biotech': 22.0,
  'Transport': 6.5,
  'Cybersecurity': 24.5,
  'Construction': 6.8,
  'Consumer Electronics': 13.5,
  'Logistics': 8.8,
  'Finance': 16.5,
  'Automotive': 10.5,
  'Semiconductors': 20.0,
};

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export default function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCluster, setSelectedCluster] = useState<ClusterType | 'All'>('All');
  const [selectedCompany, setSelectedCompany] = useState<ScoredCompany | null>(null);
  const [isGeneratingThesis, setIsGeneratingThesis] = useState(false);
  const [thesis, setThesis] = useState<string | null>(null);
  const [portfolio, setPortfolio] = useState<ScoredCompany[]>([]);
  
  // LBO Assumptions
  const [lboAssumptions, setLboAssumptions] = useState({
    entryMultiple: 10,
    targetDebt: 4.5,
    exitMultiple: 12,
    years: 5
  });

  const companies = useMemo(() => clusterCompanies(MOCK_COMPANIES), []);
  
  const filteredCompanies = useMemo(() => {
    return companies.filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           c.industry.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCluster = selectedCluster === 'All' || c.cluster === selectedCluster;
      return matchesSearch && matchesCluster;
    });
  }, [companies, searchTerm, selectedCluster]);

  const stats = useMemo(() => {
    const topPick = companies[0];
    const avgScore = Math.round(companies.reduce((acc, c) => acc + c.peScore, 0) / companies.length);
    const growthCount = companies.filter(c => c.cluster === 'Growth Buyout').length;
    const distressedCount = companies.filter(c => c.cluster === 'Distressed Target').length;
    
    return { topPick, avgScore, growthCount, distressedCount };
  }, [companies]);

  const currentLbo = useMemo(() => {
    if (!selectedCompany) return null;
    return calculateLBO(
      selectedCompany, 
      lboAssumptions.entryMultiple, 
      lboAssumptions.targetDebt, 
      lboAssumptions.exitMultiple, 
      lboAssumptions.years
    );
  }, [selectedCompany, lboAssumptions]);

  const generateThesis = async (company: ScoredCompany) => {
    setIsGeneratingThesis(true);
    setThesis(null);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Act as a Private Equity Investment Associate. Generate a concise, high-impact investment thesis (3 bullet points) for ${company.name}, a company in the ${company.industry} industry. 
        Context: 
        - EBITDA Margin: ${company.ebitdaMargin}%
        - Debt/EBITDA: ${company.debtToEbitda}x
        - Revenue Growth: ${company.revenueGrowth}%
        - ROIC: ${company.roic}%
        - PE Classification: ${company.cluster}
        Focus on value creation levers and potential risks.`
      });
      setThesis(response.text || "Unable to generate thesis at this time.");
    } catch (error) {
      console.error("Gemini Error:", error);
      setThesis("Strategic analysis unavailable. Please check API configuration.");
    } finally {
      setIsGeneratingThesis(false);
    }
  };

  useEffect(() => {
    if (selectedCompany) {
      setLboAssumptions({
        entryMultiple: selectedCompany.valuationMultiple,
        // Standard PE leverage is often 4-6x EBITDA, or current if higher
        targetDebt: Math.max(selectedCompany.debtToEbitda, 4.5),
        exitMultiple: selectedCompany.valuationMultiple + 1, // Assume 1x multiple expansion as base
        years: 5
      });
      generateThesis(selectedCompany);
    }
  }, [selectedCompany]);

  return (
    <div className="min-h-screen bg-[#F1F3F5] text-[#1A1C1E] font-sans selection:bg-emerald-100">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-[#0F172A] rounded flex items-center justify-center">
              <BarChart3 className="text-emerald-400 w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-[#0F172A]">EquityScan <span className="text-emerald-600">Pro</span></h1>
          </div>
          <div className="flex items-center gap-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search universe..."
                className="pl-10 pr-4 py-2 bg-gray-100 border-none rounded-lg text-sm w-80 focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="h-8 w-px bg-gray-200" />
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100">
              <Zap className="w-3 h-3 fill-emerald-600" />
              REAL-TIME ENGINE ACTIVE
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-6 py-8">
        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard 
            title="Conviction Target" 
            value={stats.topPick.name} 
            subValue={`Score: ${stats.topPick.peScore}/100`}
            icon={<Target className="text-emerald-600" />}
            trend="High Priority"
            trendUp={true}
          />
          <StatCard 
            title="Universe Avg Score" 
            value={stats.avgScore.toString()} 
            subValue="Normalized PE Metrics"
            icon={<Activity className="text-blue-600" />}
            trend="+1.2% MoM"
            trendUp={true}
          />
          <StatCard 
            title="Growth Buyouts" 
            value={stats.growthCount.toString()} 
            subValue="High ROIC Candidates"
            icon={<TrendingUp className="text-emerald-500" />}
            trend="Identified"
            trendUp={true}
          />
          <StatCard 
            title="Distressed Watch" 
            value={stats.distressedCount.toString()} 
            subValue="Turnaround Potential"
            icon={<AlertCircle className="text-red-500" />}
            trend="Active"
            trendUp={false}
          />
        </div>

        {/* Portfolio Overview (Conditional) */}
        {portfolio.length > 0 && (
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="mb-8 bg-[#0F172A] rounded-xl p-6 text-white shadow-2xl border border-emerald-500/20"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-500/20 rounded-lg">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-black text-lg">Active Pipeline Analysis</h3>
                  <p className="text-gray-400 text-xs uppercase tracking-widest font-bold">Aggregate Portfolio Metrics</p>
                </div>
              </div>
              <div className="flex gap-8">
                <div className="text-right">
                  <div className="text-[10px] font-bold text-gray-400 uppercase">Avg PE Score</div>
                  <div className="text-xl font-black text-emerald-400">
                    {Math.round(portfolio.reduce((acc, p) => acc + p.peScore, 0) / portfolio.length)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-bold text-gray-400 uppercase">Total EV</div>
                  <div className="text-xl font-black text-blue-400">
                    ${Math.round(portfolio.reduce((acc, p) => acc + (p.ebitda * p.valuationMultiple), 0))}M
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-bold text-gray-400 uppercase">Avg IRR</div>
                  <div className="text-xl font-black text-purple-400">
                    {Math.round(portfolio.reduce((acc, p) => acc + p.lbo.projectedIRR, 0) / portfolio.length)}%
                  </div>
                </div>
              </div>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {portfolio.map(p => (
                <div key={p.id} className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-lg border border-white/10 shrink-0">
                  <div className="text-xs font-bold">{p.name}</div>
                  <div className="text-[10px] font-mono text-emerald-400">{p.peScore}</div>
                  <button 
                    onClick={() => setPortfolio(prev => prev.filter(item => item.id !== p.id))}
                    className="p-1 hover:bg-white/10 rounded-full"
                  >
                    <X className="w-3 h-3 text-gray-500" />
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Table Area */}
          <div className="lg:col-span-3 space-y-8">
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-white">
                <div className="flex items-center gap-4">
                  <h2 className="font-bold text-gray-900 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-emerald-600" />
                    Deal Sourcing Pipeline
                  </h2>
                  <div className="flex gap-1">
                    {(['All', 'Growth Buyout', 'Distressed Target', 'Turnaround Case', 'Stable Cash Cow'] as const).map(c => (
                      <button
                        key={c}
                        onClick={() => setSelectedCluster(c)}
                        className={cn(
                          "px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all border",
                          selectedCluster === c 
                            ? "bg-[#0F172A] text-white border-[#0F172A]" 
                            : "bg-white text-gray-500 border-gray-200 hover:border-gray-400"
                        )}
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                  Showing {filteredCompanies.length} Assets
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-50/50 text-[10px] uppercase tracking-widest text-gray-400 font-black border-b border-gray-100">
                      <th className="px-6 py-4">Rank</th>
                      <th className="px-6 py-4">Company</th>
                      <th className="px-6 py-4">EBITDA %</th>
                      <th className="px-6 py-4">Debt/EBITDA</th>
                      <th className="px-6 py-4">ROIC</th>
                      <th className="px-6 py-4">Sentiment</th>
                      <th className="px-6 py-4">PE Score</th>
                      <th className="px-6 py-4">Classification</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    <AnimatePresence mode="popLayout">
                      {filteredCompanies.map((company) => (
                        <motion.tr 
                          layout
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          key={company.id} 
                          onClick={() => setSelectedCompany(company)}
                          className={cn(
                            "hover:bg-gray-50 transition-colors group cursor-pointer",
                            selectedCompany?.id === company.id && "bg-emerald-50/50"
                          )}
                        >
                          <td className="px-6 py-4 font-mono text-xs text-gray-400">#{company.rank.toString().padStart(2, '0')}</td>
                          <td className="px-6 py-4">
                            <div className="font-bold text-gray-900">{company.name}</div>
                            <div className="text-[10px] text-gray-400 uppercase font-bold">{company.industry}</div>
                          </td>
                          <td className="px-6 py-4 font-mono text-sm font-medium">{company.ebitdaMargin}%</td>
                          <td className="px-6 py-4 font-mono text-sm font-medium">{company.debtToEbitda}x</td>
                          <td className="px-6 py-4 font-mono text-sm font-medium">{company.roic}%</td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-1.5">
                              <div className={cn(
                                "w-2 h-2 rounded-full",
                                company.sentimentScore > 0.5 ? "bg-emerald-500" : 
                                company.sentimentScore > 0 ? "bg-blue-500" : "bg-red-500"
                              )} />
                              <span className="text-xs font-bold text-gray-600">
                                {company.sentimentScore > 0.5 ? 'Bullish' : 
                                 company.sentimentScore > 0 ? 'Neutral' : 'Bearish'}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-black text-gray-900">{company.peScore}</span>
                              <div className="w-16 h-1 bg-gray-100 rounded-full overflow-hidden">
                                <div 
                                  className={cn(
                                    "h-full rounded-full transition-all duration-1000",
                                    company.peScore > 75 ? "bg-emerald-500" : 
                                    company.peScore > 50 ? "bg-blue-500" : "bg-amber-500"
                                  )}
                                  style={{ width: `${company.peScore}%` }}
                                />
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span 
                              className="px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest border"
                              style={{ 
                                backgroundColor: `${CLUSTER_COLORS[company.cluster]}10`,
                                color: CLUSTER_COLORS[company.cluster],
                                borderColor: `${CLUSTER_COLORS[company.cluster]}30`
                              }}
                            >
                              {company.cluster}
                            </span>
                          </td>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Advanced Visualization Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                <h3 className="font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <PieChartIcon className="w-4 h-4 text-emerald-600" />
                  Cluster Distribution & Efficiency
                </h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
                      <XAxis 
                        type="number" 
                        dataKey="ebitdaMargin" 
                        name="EBITDA Margin" 
                        unit="%" 
                        fontSize={10}
                        tick={{ fill: '#94a3b8' }}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <YAxis 
                        type="number" 
                        dataKey="roic" 
                        name="ROIC" 
                        unit="%" 
                        fontSize={10}
                        tick={{ fill: '#94a3b8' }}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <ZAxis type="number" dataKey="peScore" range={[50, 400]} />
                      <Tooltip 
                        cursor={{ strokeDasharray: '3 3' }} 
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload as ScoredCompany;
                            return (
                              <div className="bg-[#0F172A] text-white p-3 rounded-lg shadow-2xl border border-gray-700">
                                <p className="text-xs font-black mb-1">{data.name}</p>
                                <div className="space-y-1">
                                  <p className="text-[10px] text-gray-400">EBITDA: {data.ebitdaMargin}%</p>
                                  <p className="text-[10px] text-gray-400">ROIC: {data.roic}%</p>
                                  <p className="text-[10px] font-bold" style={{ color: CLUSTER_COLORS[data.cluster] }}>
                                    {data.cluster}
                                  </p>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Scatter name="Companies" data={companies}>
                        {companies.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={CLUSTER_COLORS[entry.cluster]} />
                        ))}
                      </Scatter>
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                <h3 className="font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Risk/Return Profile (Radar)
                </h3>
                <div className="h-[300px] flex items-center justify-center">
                  {selectedCompany ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={[
                        { subject: 'Margin', A: selectedCompany.ebitdaMargin, fullMark: 50 },
                        { subject: 'Growth', A: selectedCompany.revenueGrowth, fullMark: 50 },
                        { subject: 'ROIC', A: selectedCompany.roic, fullMark: 50 },
                        { subject: 'FCF', A: selectedCompany.fcfStability * 50, fullMark: 50 },
                        { subject: 'Value', A: Math.max(0, (25 - selectedCompany.valuationMultiple) * 2), fullMark: 50 },
                      ]}>
                        <PolarGrid stroke="#e2e8f0" />
                        <PolarAngleAxis dataKey="subject" fontSize={10} tick={{ fill: '#64748b', fontWeight: 'bold' }} />
                        <Radar
                          name={selectedCompany.name}
                          dataKey="A"
                          stroke="#10b981"
                          fill="#10b981"
                          fillOpacity={0.5}
                        />
                      </RadarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="text-center text-gray-400">
                      <Info className="w-8 h-8 mx-auto mb-2 opacity-20" />
                      <p className="text-xs font-bold uppercase tracking-widest">Select a company to view risk radar</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Side Panel: LBO & AI Analysis */}
          <div className="lg:col-span-1 space-y-8">
            <AnimatePresence mode="wait">
              {selectedCompany ? (
                <motion.div 
                  initial={{ x: 50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: 50, opacity: 0 }}
                  className="bg-white rounded-xl border border-gray-200 shadow-xl overflow-hidden sticky top-24"
                >
                  <div className="bg-[#0F172A] p-6 text-white relative">
                    <button 
                      onClick={() => setSelectedCompany(null)}
                      className="absolute top-4 right-4 p-1 hover:bg-white/10 rounded-full transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-1">Target Profile</div>
                    <h3 className="text-xl font-black truncate">{selectedCompany.name}</h3>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs font-bold bg-white/10 px-2 py-0.5 rounded">{selectedCompany.industry}</span>
                      <span className="text-xs font-bold text-emerald-400">Score: {selectedCompany.peScore}</span>
                    </div>
                  </div>

                  <div className="p-6 space-y-8">
                    {/* LBO Simulator */}
                    <div>
                      <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <DollarSign className="w-3 h-3" />
                        LBO Returns Simulator
                      </h4>
                      <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                          <div className="text-[10px] font-bold text-emerald-600 uppercase">Projected IRR</div>
                          <div className="text-xl font-black text-emerald-700">{currentLbo?.projectedIRR}%</div>
                        </div>
                        <div className="p-3 bg-blue-50 rounded-lg border border-blue-100">
                          <div className="text-[10px] font-bold text-blue-600 uppercase">MOIC</div>
                          <div className="text-xl font-black text-blue-700">{currentLbo?.moic}x</div>
                        </div>
                        <div className="p-3 bg-purple-50 rounded-lg border border-purple-100">
                          <div className="text-[10px] font-bold text-purple-600 uppercase">Debt Paydown</div>
                          <div className="text-xl font-black text-purple-700">${currentLbo?.debtPaydown}M</div>
                        </div>
                        <div className="p-3 bg-amber-50 rounded-lg border border-amber-100">
                          <div className="text-[10px] font-bold text-amber-600 uppercase">Exit Value</div>
                          <div className="text-xl font-black text-amber-700">${currentLbo?.exitValue}M</div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <AssumptionSlider 
                          label="Entry Multiple" 
                          value={lboAssumptions.entryMultiple} 
                          unit="x"
                          min={5} max={25} step={0.5}
                          onChange={(v) => setLboAssumptions(prev => ({ ...prev, entryMultiple: v }))}
                        />
                        <AssumptionSlider 
                          label="Target Debt" 
                          value={lboAssumptions.targetDebt} 
                          unit="x"
                          min={1} max={8} step={0.1}
                          onChange={(v) => setLboAssumptions(prev => ({ ...prev, targetDebt: v }))}
                        />
                        <AssumptionSlider 
                          label="Exit Multiple" 
                          value={lboAssumptions.exitMultiple} 
                          unit="x"
                          min={5} max={25} step={0.5}
                          onChange={(v) => setLboAssumptions(prev => ({ ...prev, exitMultiple: v }))}
                        />
                      </div>
                    </div>

                    <div className="h-px bg-gray-100" />

                    {/* Valuation Benchmarks */}
                    <div>
                      <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <Layers className="w-3 h-3 text-blue-500" />
                        Valuation Benchmarks
                      </h4>
                      <div className="space-y-1">
                        <BenchmarkRow 
                          label="Entry EV/EBITDA" 
                          value={`${selectedCompany.valuationMultiple}x`} 
                          subValue="Current Market"
                        />
                        <BenchmarkRow 
                          label="Industry Median" 
                          value={`${INDUSTRY_MEDIANS[selectedCompany.industry] || 12.5}x`} 
                          subValue={`${selectedCompany.industry} Sector`} 
                        />
                        <BenchmarkRow 
                          label="Target Exit" 
                          value={`${lboAssumptions.exitMultiple}x`} 
                          subValue="5-Year Horizon"
                        />
                      </div>
                    </div>

                    <div className="h-px bg-gray-100" />

                    {/* Market Sentiment */}
                    <div>
                      <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <MessageSquare className="w-3 h-3 text-emerald-500" />
                        Market Sentiment Trend
                      </h4>
                      <div className="h-[120px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={selectedCompany.sentimentHistory}>
                            <XAxis dataKey="date" hide />
                            <YAxis domain={[-1, 1]} hide />
                            <Tooltip 
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  return (
                                    <div className="bg-[#0F172A] text-white p-2 rounded shadow-xl border border-white/10">
                                      <div className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">
                                        {payload[0].payload.date}
                                      </div>
                                      <div className="text-xs font-black text-emerald-400">
                                        Score: {payload[0].value}
                                      </div>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <Line 
                              type="monotone" 
                              dataKey="score" 
                              stroke="#10b981" 
                              strokeWidth={2} 
                              dot={{ fill: '#10b981', r: 4 }}
                              activeDot={{ r: 6 }}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    <div className="h-px bg-gray-100" />

                    {/* AI Thesis */}
                    <div>
                      <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <Sparkles className="w-3 h-3 text-purple-500" />
                        AI Strategic Rationale
                      </h4>
                      {isGeneratingThesis ? (
                        <div className="flex flex-col items-center justify-center py-8 text-gray-400">
                          <Loader2 className="w-6 h-6 animate-spin mb-2" />
                          <span className="text-[10px] font-bold uppercase tracking-widest">Synthesizing Market Data...</span>
                        </div>
                      ) : (
                        <div className="text-xs text-gray-600 leading-relaxed bg-gray-50 p-4 rounded-lg border border-gray-100 italic">
                          {thesis || "No analysis generated."}
                        </div>
                      )}
                    </div>

                    <button 
                      onClick={() => {
                        if (selectedCompany && !portfolio.find(p => p.id === selectedCompany.id)) {
                          setPortfolio(prev => [...prev, selectedCompany]);
                        }
                      }}
                      className={cn(
                        "w-full py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg",
                        portfolio.find(p => p.id === selectedCompany.id)
                          ? "bg-emerald-600 text-white cursor-default"
                          : "bg-[#0F172A] hover:bg-black text-white"
                      )}
                    >
                      {portfolio.find(p => p.id === selectedCompany.id) ? 'Added to Pipeline' : 'Add to Active Pipeline'}
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              ) : (
                <div className="space-y-8">
                  <div className="bg-[#0F172A] rounded-xl p-6 text-white shadow-xl relative overflow-hidden">
                    <div className="relative z-10">
                      <h3 className="font-black text-lg mb-2">Deal Intelligence</h3>
                      <p className="text-gray-400 text-xs mb-6 leading-relaxed">
                        Select a company from the pipeline to run advanced LBO simulations and generate AI-powered investment theses.
                      </p>
                      <div className="space-y-3">
                        <div className="flex items-center gap-3 text-[10px] font-bold text-emerald-400">
                          <ShieldCheck className="w-4 h-4" />
                          PROPRIETARY SCORING
                        </div>
                        <div className="flex items-center gap-3 text-[10px] font-bold text-blue-400">
                          <Activity className="w-4 h-4" />
                          SENTIMENT OVERLAY
                        </div>
                      </div>
                    </div>
                    <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl" />
                  </div>

                  <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2 text-sm">
                      <MessageSquare className="w-4 h-4 text-emerald-600" />
                      Recent Market Alerts
                    </h3>
                    <div className="space-y-4">
                      <AlertItem 
                        type="positive" 
                        title="TechFlow Systems" 
                        desc="Strong Q3 earnings beat; FCF conversion at record highs." 
                      />
                      <AlertItem 
                        type="negative" 
                        title="RetailEdge Inc" 
                        desc="Debt covenant breach risk increasing; inventory turnover slowing." 
                      />
                      <AlertItem 
                        type="neutral" 
                        title="HealthCore" 
                        desc="Regulatory tailwinds expected in H2 following policy shift." 
                      />
                    </div>
                  </div>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );
}

function StatCard({ title, value, subValue, icon, trend, trendUp }: { 
  title: string; 
  value: string; 
  subValue: string; 
  icon: React.ReactNode;
  trend: string;
  trendUp: boolean;
}) {
  return (
    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all group">
      <div className="flex items-start justify-between mb-4">
        <div className="p-2 bg-gray-50 rounded-lg group-hover:bg-emerald-50 transition-colors">
          {icon}
        </div>
        <div className={cn(
          "flex items-center gap-1 text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest",
          trendUp ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-600"
        )}>
          {trendUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
          {trend}
        </div>
      </div>
      <div className="space-y-1">
        <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{title}</h4>
        <div className="text-xl font-black text-gray-900 truncate">{value}</div>
        <p className="text-[10px] font-bold text-gray-400">{subValue}</p>
      </div>
    </div>
  );
}

function AssumptionSlider({ label, value, unit, min, max, step, onChange }: { 
  label: string; 
  value: number; 
  unit: string;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <label className="text-[10px] font-bold text-gray-500 uppercase">{label}</label>
        <span className="text-xs font-black text-gray-900">{value}{unit}</span>
      </div>
      <input 
        type="range" 
        min={min} max={max} step={step} 
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
      />
    </div>
  );
}

function AlertItem({ type, title, desc }: { type: 'positive' | 'negative' | 'neutral', title: string, desc: string }) {
  const colors = {
    positive: 'bg-emerald-500',
    negative: 'bg-red-500',
    neutral: 'bg-blue-500'
  };
  return (
    <div className="flex gap-3">
      <div className={cn("w-1 h-auto rounded-full shrink-0", colors[type])} />
      <div>
        <div className="text-xs font-bold text-gray-900">{title}</div>
        <p className="text-[10px] text-gray-500 leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}

function BenchmarkRow({ label, value, subValue }: { label: string; value: string; subValue: string }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
      <div>
        <div className="text-xs font-semibold text-gray-800">{label}</div>
        <div className="text-[10px] text-gray-400">{subValue}</div>
      </div>
      <div className="text-sm font-mono font-bold text-emerald-600">{value}</div>
    </div>
  );
}
