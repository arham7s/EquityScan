export interface CompanyMetrics {
  id: string;
  name: string;
  industry: string;
  ebitdaMargin: number; // %
  debtToEbitda: number; // Multiple
  revenueGrowth: number; // %
  roic: number; // %
  fcfStability: number; // 0-1 score
  valuationMultiple: number; // EV/EBITDA
  revenue: number; // $M
  ebitda: number; // $M
  marketCap: number; // $M
  sentimentScore: number; // -1 to 1
  sentimentHistory: { date: string; score: number }[];
}

export type ClusterType = 'Growth Buyout' | 'Distressed Target' | 'Turnaround Case' | 'Stable Cash Cow' | 'Overvalued';

export interface LBOMetrics {
  projectedIRR: number; // %
  moic: number; // Multiple
  entryEquity: number; // $M
  exitValue: number; // $M
  debtPaydown: number; // $M
}

export interface ScoredCompany extends CompanyMetrics {
  peScore: number; // 0-100
  cluster: ClusterType;
  rank: number;
  lbo: LBOMetrics;
}
